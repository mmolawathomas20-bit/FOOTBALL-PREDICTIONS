# FPBS Platform Starter

A full-stack starter for Football Prediction By Sonytizer (FPBS), using Node.js, Express, SQLite, and a responsive browser interface.

## Included
- Responsive public site and match cards
- Fixtures endpoint powered by API-FOOTBALL when an API key is configured
- Admin login with bcrypt password hashing and JWT
- Admin CRUD for predictions
- Prediction history with outcome recording
- Accuracy summary based only on predictions marked as settled
- Premium access flag and protected premium-predictions endpoint
- Rate limiting, Helmet security headers, and server-side validation
- Contact details for FPBS
- EFT membership instructions for R200 per 30 days, with manual verification and the supplied Capitec receiving details

## Requirements
- Node.js 20 or newer
- An API-FOOTBALL/API-Sports account and API key for live fixtures (optional)
- A real payment provider account and server-side webhook integration before selling subscriptions

## Run locally
1. Copy `.env.example` to `.env`.
2. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and a long random `JWT_SECRET`.
3. Install dependencies: `npm install`
4. Start: `npm start`
5. Open `http://localhost:3000`

The database is created automatically in `data/fpbs.sqlite`.

## Admin
Use the email/password from `.env` at `/api/admin/login`. The frontend includes an admin login form. Keep admin credentials private. Change them before deploying.

## Live fixtures
Set `FOOTBALL_API_KEY` in `.env`. This starter requests fixtures from the current date through the next seven days. API provider plans and endpoint quotas may apply. If no key is configured, the fixtures panel explains that live data is not connected.

## Premium membership — important
The website displays EFT instructions for R200 per 30 days. Payment is manual: customers must contact FPBS after transferring funds, and an admin must verify the money arrived and activate access. This starter does **not** yet provide customer self-registration, proof-of-payment submission, automatic expiry of memberships, or automated WhatsApp/email delivery. Before scaling this process, implement customer accounts, 30-day expiry enforcement, secure admin membership management, and verified payment records. Do not activate access based only on a screenshot. If you later automate payments, verify provider webhooks server-side. Never trust a payment-success message from the browser. Add terms, refund/cancellation policy, privacy notice, and any required legal/compliance checks.

## Deployment
Deploy to a Node.js host that supports persistent storage, or replace SQLite with managed PostgreSQL before using multiple server instances. Set environment variables in the host dashboard, use HTTPS, and do not upload `.env` or the database. Back up the database regularly.

## Before launch
- Replace demonstration predictions and record real prediction outcomes.
- Do not claim accuracy until calculated from a meaningful, transparent settled history.
- Configure live API credentials and review provider licensing/usage terms.
- Add a payment provider and verified webhook flow if charging users.
- Add privacy policy and terms appropriate to your business and applicable law.


## Customer accounts and manual EFT membership
- Customers can register with name, email and a password (10+ characters), sign in, submit an EFT reference, and check membership status.
- Admin dashboard includes pending EFT review. Approve only after confirming the funds have actually arrived.
- Approval activates a 30-day membership. If the customer already has active time remaining, the new 30 days are added after the existing expiry.
- Premium predictions are available only through the customer-authenticated premium endpoint when the membership has not expired.
- This version does not send WhatsApp group/individual messages or email predictions automatically. Those require WhatsApp Business Platform configuration and an email delivery provider.
- The member login token is held in the page's memory only and is lost on refresh; sign in again after refreshing.
- The supplied Capitec details are displayed publicly in the membership section. If you don't want them public, remove that section or gate it behind a secure customer/admin view.
- Before public launch, set a strong random `JWT_SECRET`, unique admin credentials in `.env`, use HTTPS hosting, set up backups, and have the site/security/payment workflow reviewed.


## Android-friendly deployment (Render)
**Important:** this app uses SQLite. Do not run a paid-membership site on a free web service with an ephemeral filesystem: customer accounts, payment requests, predictions, and membership records could be lost after a restart/redeploy. Use a paid web service with a persistent disk, or migrate the app to a managed persistent database before production.

1. On your Android phone, download and extract the project ZIP.
2. Create a private repository on GitHub and upload the contents of the `fpbs-platform` folder (not the outer folder or ZIP file). Keep `.env` files and real secrets out of GitHub.
3. Sign in to Render and create a **Web Service** connected to that repository.
4. Set **Build Command** to `npm install` and **Start Command** to `npm start`.
5. Choose a paid service plan that supports a persistent disk. Add a disk with mount path `/var/data`.
6. Add these environment variables in the Render dashboard:
   - `NODE_ENV` = `production`
   - `DATA_DIR` = `/var/data`
   - `ADMIN_EMAIL` = your private admin email
   - `ADMIN_PASSWORD` = a unique, strong admin password
   - `JWT_SECRET` = a random secret of at least 32 characters (generate a new one; do not reuse a password)
   - `FOOTBALL_API_KEY` = your API-FOOTBALL key, if you have one
7. Deploy and wait for the deployment to finish. Open the generated `onrender.com` address on your phone and test account registration, admin login, payment submission, and payment approval before sharing it publicly.
8. Save a backup of the database regularly. Do not share admin credentials or secret environment values.

## Feature status
Customer registration/login, EFT reference submissions, admin payment review, and 30-day membership expiry checks are included. Membership activation is manual and should happen only after the bank confirms the funds arrived. Automatic WhatsApp group/individual delivery and automatic email delivery are not implemented yet. Live fixtures require a configured football-data API key. Add privacy, terms, refund/cancellation, and responsible-gambling information before launch.
