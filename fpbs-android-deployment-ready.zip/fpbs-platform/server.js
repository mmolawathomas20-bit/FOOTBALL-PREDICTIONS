require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.warn("WARNING: Set JWT_SECRET to a random secret of at least 32 characters in .env before deployment.");
}
const tokenSecret = JWT_SECRET || "local-development-only-change-this-secret-32";
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "fpbs.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  league TEXT NOT NULL,
  kickoff TEXT NOT NULL,
  prediction TEXT NOT NULL,
  predicted_score TEXT DEFAULT '',
  confidence INTEGER DEFAULT 50,
  notes TEXT DEFAULT '',
  premium INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  actual_result TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  premium INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payment_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_email TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  payment_reference TEXT NOT NULL,
  amount_cents INTEGER NOT NULL DEFAULT 20000,
  status TEXT NOT NULL DEFAULT 'pending',
  submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TEXT,
  reviewed_by TEXT,
  membership_expires_at TEXT
);`);
// Lightweight schema migration for existing installations.
const membershipColumns = db.prepare("PRAGMA table_info(memberships)").all().map(c => c.name);
if (!membershipColumns.includes("expires_at")) db.exec("ALTER TABLE memberships ADD COLUMN expires_at TEXT");
const count = db.prepare("SELECT COUNT(*) AS n FROM predictions").get().n;
if (!count) {
  const add = db.prepare(`INSERT INTO predictions
  (home_team,away_team,league,kickoff,prediction,predicted_score,confidence,notes,premium,status)
  VALUES (?,?,?,?,?,?,?,?,?,?)`);
  add.run("Example Home FC", "Example Away FC", "Example League", "2026-12-01T15:00:00Z", "Home win", "2-1", 60, "DEMO ONLY — replace with a researched prediction.", 0, "pending");
  add.run("Example United", "Example City", "Example League", "2026-12-02T17:30:00Z", "Draw", "1-1", 35, "DEMO ONLY — replace with a researched prediction.", 1, "pending");
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    req.user = jwt.verify(token, tokenSecret);
    next();
  } catch {
    res.status(401).json({ error: "Please log in again." });
  }
}
function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
function cleanText(value, max = 180) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function validatePrediction(body) {
  const home_team = cleanText(body.home_team, 80);
  const away_team = cleanText(body.away_team, 80);
  const league = cleanText(body.league, 80);
  const kickoff = cleanText(body.kickoff, 60);
  const prediction = cleanText(body.prediction, 80);
  const predicted_score = cleanText(body.predicted_score, 20);
  const notes = cleanText(body.notes, 1000);
  const confidence = Number(body.confidence);
  if (!home_team || !away_team || !league || !kickoff || !prediction) throw new Error("Home team, away team, league, kickoff and prediction are required.");
  if (!Number.isInteger(confidence) || confidence < 1 || confidence > 100) throw new Error("Confidence must be an integer from 1 to 100.");
  if (!Number.isFinite(Date.parse(kickoff))) throw new Error("Kickoff must be a valid date/time.");
  return { home_team, away_team, league, kickoff, prediction, predicted_score, notes, confidence, premium: body.premium ? 1 : 0 };
}

app.get("/api/health", (req, res) => res.json({ ok: true, service: "FPBS" }));

app.get("/api/predictions", (req, res) => {
  const rows = db.prepare("SELECT * FROM predictions WHERE premium = 0 ORDER BY kickoff ASC").all();
  res.json(rows);
});

app.get("/api/premium", auth, (req, res) => {
  const email = String(req.user.email || "").toLowerCase();
  const membership = db.prepare("SELECT premium FROM memberships WHERE email = ?").get(email);
  if (req.user.role !== "admin" && !activeMembership(email)) return res.status(403).json({ error: "Premium membership is not active. Submit an EFT reference and wait for verification." });
  res.json(db.prepare("SELECT * FROM predictions WHERE premium = 1 ORDER BY kickoff ASC").all());
});

app.get("/api/stats", (req, res) => {
  const total = db.prepare("SELECT COUNT(*) n FROM predictions WHERE status != 'pending'").get().n;
  const correct = db.prepare("SELECT COUNT(*) n FROM predictions WHERE status = 'settled' AND lower(actual_result) = 'correct'").get().n;
  const settled = db.prepare("SELECT COUNT(*) n FROM predictions WHERE status = 'settled'").get().n;
  res.json({ settled, correct, accuracy: settled ? Math.round(correct / settled * 100) : null });
});

app.get("/api/fixtures", async (req, res) => {
  const apiKey = process.env.FOOTBALL_API_KEY;
  if (!apiKey) return res.status(503).json({ error: "Live fixtures are not connected yet. Add FOOTBALL_API_KEY in your .env file." });
  const base = (process.env.FOOTBALL_API_BASE_URL || "https://v3.football.api-sports.io").replace(/\/$/, "");
  const from = new Date().toISOString().slice(0, 10);
  const toDate = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
  try {
    const upstream = await fetch(`${base}/fixtures?from=${from}&to=${toDate}&timezone=Africa/Johannesburg`, {
      headers: { "x-apisports-key": apiKey }
    });
    if (!upstream.ok) return res.status(502).json({ error: "Football data provider returned an error." });
    const data = await upstream.json();
    const fixtures = (data.response || []).slice(0, 100).map(item => ({
      id: item.fixture?.id,
      kickoff: item.fixture?.date,
      status: item.fixture?.status?.long,
      league: item.league?.name,
      home: item.teams?.home?.name,
      away: item.teams?.away?.name,
      homeGoals: item.goals?.home,
      awayGoals: item.goals?.away
    }));
    res.json(fixtures);
  } catch {
    res.status(502).json({ error: "Could not retrieve fixtures. Try again later." });
  }
});


function customerAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const payload = jwt.verify(token, tokenSecret);
    if (payload.role !== "customer") return res.status(403).json({ error: "Customer account required." });
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: "Please log in again." });
  }
}
function activeMembership(email) {
  const row = db.prepare("SELECT premium, expires_at FROM memberships WHERE email = ?").get(String(email).toLowerCase());
  return Boolean(row && row.premium && row.expires_at && Date.parse(row.expires_at) > Date.now());
}

app.post("/api/customer/register", rateLimit({ windowMs: 15 * 60 * 1000, limit: 8 }), async (req, res) => {
  const name = cleanText(req.body.name, 100);
  const email = cleanText(req.body.email, 150).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (name.length < 2) return res.status(400).json({ error: "Enter your name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 10) return res.status(400).json({ error: "Use a password with at least 10 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    db.prepare("INSERT INTO customers(name,email,password_hash) VALUES(?,?,?)").run(name, email, hash);
    res.status(201).json({ ok: true, message: "Account created. Sign in, then submit your EFT payment reference." });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with that email already exists." });
    res.status(500).json({ error: "Could not create your account." });
  }
});

app.post("/api/customer/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), async (req, res) => {
  const email = cleanText(req.body.email, 150).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const customer = db.prepare("SELECT id,name,email,password_hash FROM customers WHERE email=?").get(email);
  if (!customer || !(await bcrypt.compare(password, customer.password_hash))) return res.status(401).json({ error: "Invalid email or password." });
  const token = jwt.sign({ email: customer.email, role: "customer", name: customer.name }, tokenSecret, { expiresIn: "7d" });
  const membership = db.prepare("SELECT premium, expires_at FROM memberships WHERE email=?").get(email);
  res.json({ token, name: customer.name, email, membership: membership || { premium: 0, expires_at: null } });
});

app.get("/api/customer/me", customerAuth, (req, res) => {
  const membership = db.prepare("SELECT premium, expires_at FROM memberships WHERE email=?").get(req.user.email);
  const latestPayment = db.prepare("SELECT id,payment_reference,amount_cents,status,submitted_at,reviewed_at,membership_expires_at FROM payment_requests WHERE customer_email=? ORDER BY id DESC LIMIT 1").get(req.user.email);
  res.json({ name: req.user.name, email: req.user.email, active: activeMembership(req.user.email), membership: membership || { premium: 0, expires_at: null }, latestPayment: latestPayment || null });
});

app.post("/api/customer/payment-requests", customerAuth, (req, res) => {
  const payment_reference = cleanText(req.body.payment_reference, 120);
  if (payment_reference.length < 3) return res.status(400).json({ error: "Enter the EFT payment reference." });
  const pending = db.prepare("SELECT id FROM payment_requests WHERE customer_email=? AND status='pending'").get(req.user.email);
  if (pending) return res.status(409).json({ error: "You already have a payment awaiting review." });
  const result = db.prepare("INSERT INTO payment_requests(customer_email,customer_name,payment_reference,amount_cents) VALUES(?,?,?,20000)")
    .run(req.user.email, cleanText(req.user.name,100), payment_reference);
  res.status(201).json({ ok: true, id: result.lastInsertRowid, message: "Payment reference submitted. FPBS will verify that the funds arrived before activating membership." });
});

app.get("/api/customer/premium", customerAuth, (req, res) => {
  if (!activeMembership(req.user.email)) return res.status(403).json({ error: "Your membership is not active. Submit payment details and wait for verification." });
  res.json(db.prepare("SELECT * FROM predictions WHERE premium=1 ORDER BY kickoff ASC").all());
});

app.get("/api/admin/payment-requests", auth, adminOnly, (req, res) => {
  res.json(db.prepare("SELECT * FROM payment_requests ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, submitted_at DESC").all());
});
app.patch("/api/admin/payment-requests/:id/review", auth, adminOnly, (req, res) => {
  const id = Number(req.params.id);
  const decision = req.body.decision;
  if (!Number.isInteger(id) || !["approve","reject"].includes(decision)) return res.status(400).json({error:"Invalid review request."});
  const payment = db.prepare("SELECT * FROM payment_requests WHERE id=?").get(id);
  if (!payment) return res.status(404).json({error:"Payment request not found."});
  if (payment.status !== "pending") return res.status(409).json({error:"This payment request has already been reviewed."});
  if (decision === "reject") {
    db.prepare("UPDATE payment_requests SET status='rejected', reviewed_at=CURRENT_TIMESTAMP, reviewed_by=? WHERE id=?").run(req.user.email,id);
    return res.json({ok:true,status:"rejected"});
  }
  const previous = db.prepare("SELECT expires_at FROM memberships WHERE email=?").get(payment.customer_email);
  const now = Date.now();
  const previousExpiry = previous?.expires_at ? Date.parse(previous.expires_at) : 0;
  const start = Math.max(now, Number.isFinite(previousExpiry) ? previousExpiry : 0);
  const expiry = new Date(start + 30*24*60*60*1000).toISOString();
  db.prepare(`INSERT INTO memberships(email,premium,expires_at,updated_at) VALUES(?,1,?,CURRENT_TIMESTAMP)
    ON CONFLICT(email) DO UPDATE SET premium=1, expires_at=excluded.expires_at, updated_at=CURRENT_TIMESTAMP`)
    .run(payment.customer_email, expiry);
  db.prepare("UPDATE payment_requests SET status='approved', reviewed_at=CURRENT_TIMESTAMP, reviewed_by=?, membership_expires_at=? WHERE id=?")
    .run(req.user.email, expiry, id);
  res.json({ok:true,status:"approved",expires_at:expiry});
});

app.post("/api/admin/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), async (req, res) => {
  const email = cleanText(req.body.email, 150).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const configuredEmail = String(process.env.ADMIN_EMAIL || "").toLowerCase();
  const configuredPassword = process.env.ADMIN_PASSWORD || "";
  if (!configuredEmail || !configuredPassword || email !== configuredEmail || password !== configuredPassword) {
    return res.status(401).json({ error: "Invalid admin email or password." });
  }
  const token = jwt.sign({ email, role: "admin" }, tokenSecret, { expiresIn: "8h" });
  res.json({ token, email });
});

app.get("/api/admin/predictions", auth, adminOnly, (req, res) => {
  res.json(db.prepare("SELECT * FROM predictions ORDER BY kickoff DESC").all());
});

app.post("/api/admin/predictions", auth, adminOnly, (req, res) => {
  try {
    const p = validatePrediction(req.body);
    const result = db.prepare(`INSERT INTO predictions
      (home_team,away_team,league,kickoff,prediction,predicted_score,confidence,notes,premium)
      VALUES (@home_team,@away_team,@league,@kickoff,@prediction,@predicted_score,@confidence,@notes,@premium)`).run(p);
    res.status(201).json({ id: result.lastInsertRowid });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.put("/api/admin/predictions/:id", auth, adminOnly, (req, res) => {
  try {
    const p = validatePrediction(req.body);
    const result = db.prepare(`UPDATE predictions SET
      home_team=@home_team,away_team=@away_team,league=@league,kickoff=@kickoff,
      prediction=@prediction,predicted_score=@predicted_score,confidence=@confidence,
      notes=@notes,premium=@premium WHERE id=@id`).run({ ...p, id: Number(req.params.id) });
    if (!result.changes) return res.status(404).json({ error: "Prediction not found." });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.patch("/api/admin/predictions/:id/result", auth, adminOnly, (req, res) => {
  const status = req.body.status;
  const actual = cleanText(req.body.actual_result, 80);
  if (!["pending", "settled", "cancelled"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  if (status === "settled" && !["correct", "incorrect", "void"].includes(actual.toLowerCase())) {
    return res.status(400).json({ error: "Settled result must be correct, incorrect, or void." });
  }
  const result = db.prepare("UPDATE predictions SET status=?, actual_result=? WHERE id=?")
    .run(status, status === "settled" ? actual.toLowerCase() : "", Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Prediction not found." });
  res.json({ ok: true });
});

app.delete("/api/admin/predictions/:id", auth, adminOnly, (req, res) => {
  const result = db.prepare("DELETE FROM predictions WHERE id=?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Prediction not found." });
  res.json({ ok: true });
});


app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`FPBS running at http://localhost:${PORT}`));
